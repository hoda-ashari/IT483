public static double transaction(double bal, double amount) {
    
    // when the amount is positive that means its a deposit
    if (amount > 0) {
        // we simply return the amount
        return amount;
    } 
    // when the amount is negative then its a withdrawl
    else if (amount < 0) {
        // convert it to absolute amount
        amount = -amount;
        // check if the amount is greater than equal to the balance
        if (amount >= bal) {
            return -bal; // return the balance but in negative
        } else {
            return -amount; // else return the negative amount
        }
    
    }
        // when the amount is zero we return zero
    else {
        return 0.0;
    }
}