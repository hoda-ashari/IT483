import java.util.Scanner;

public class Lab04 {

    public static void main(String[] args) {

        Scanner stdIn = new Scanner(System.in);
        int a = 1, b = 3, c = 5;
        double x = 2.2, y = 4.4, z = 6.6, ans;

        ans = average(a, b);
        System.out.println("\naverage(a,b) = " + ans);

        ans = average(a, b, c);
        System.out.println("\naverage(a,b,c) = " + ans);

        ans = average(x, y);
        System.out.println("\naverage(x,y) = " + ans);

        ans = average(x, y, z);
        System.out.println("\naverage(x,y,z) = " + ans);
    }

    public static double average(int n1, int n2) {
        return (n1 + n2) / 2.0;
    }

    // Overloaded method Definition(s) here

    private static double average(double n1, double n2, double n3) {
        return (n1 + n2 + n3) / 3.0;
    }

    private static double average(double n1, double n2) {
        return (n1 + n2) / 2.0;
    }

    private static double average(int n1, int n2, int n3) {
        return (n1 + n2 + n3) / 3.0;
    }


}